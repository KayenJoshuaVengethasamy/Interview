package com.TwentySevenFour.back.repository;


import com.TwentySevenFour.back.models.PlanetNames;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlanetNamesRepository extends JpaRepository<PlanetNames, Long> {
}
