package com.TwentySevenFour.back.repository;

import com.TwentySevenFour.back.models.Routes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoutesRepository  extends JpaRepository<Routes, Long> {
}
