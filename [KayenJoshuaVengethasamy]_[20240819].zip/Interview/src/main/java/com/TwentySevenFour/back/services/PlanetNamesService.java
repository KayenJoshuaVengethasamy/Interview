package com.TwentySevenFour.back.services;

import com.TwentySevenFour.back.models.PlanetNames;

import java.util.List;

public interface PlanetNamesService {
    List<PlanetNames> getAllPlanetNames();
}
